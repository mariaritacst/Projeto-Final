package com.example.trabalho2025;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.Toast;
import android.widget.AdapterView;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private DBHelper dbHelper;
    private EditText edtNome, edtTipo, edtPreco;
    private Button btnAdicionar, btnAlterar, btnExcluir, btnEncerrarSessao;
    private ListView listViewProdutos;
    private ArrayList<String> listaProdutos;
    private ArrayList<Integer> listaIds;
    private int idProdutoSelecionado = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DBHelper(this);

        edtNome = findViewById(R.id.edtNome);
        edtTipo = findViewById(R.id.edtTipo);
        edtPreco = findViewById(R.id.edtPreco);
        btnAdicionar = findViewById(R.id.btnAdicionar);
        btnAlterar = findViewById(R.id.btnAlterar);
        btnExcluir = findViewById(R.id.btnExcluir);
        btnEncerrarSessao = findViewById(R.id.btnEncerrarSessao);  // Novo botão de encerrar sessão
        listViewProdutos = findViewById(R.id.listViewProdutos);

        listaProdutos = new ArrayList<>();
        listaIds = new ArrayList<>();

        // Ação para adicionar produto
        btnAdicionar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nome = edtNome.getText().toString();
                String tipo = edtTipo.getText().toString();
                double preco = Double.parseDouble(edtPreco.getText().toString());

                long id = dbHelper.adicionarProduto(nome, tipo, preco);

                if (id != -1) {
                    Toast.makeText(MainActivity.this, "Produto adicionado com sucesso!", Toast.LENGTH_SHORT).show();
                    listarProdutos();
                } else {
                    Toast.makeText(MainActivity.this, "Erro ao adicionar produto.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Ação para alterar produto
        btnAlterar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (idProdutoSelecionado == -1) {
                    Toast.makeText(MainActivity.this, "Nenhum produto selecionado para alteração.", Toast.LENGTH_SHORT).show();
                    return;
                }

                String nome = edtNome.getText().toString();
                String tipo = edtTipo.getText().toString();
                double preco = Double.parseDouble(edtPreco.getText().toString());

                boolean alterado = dbHelper.alterarProduto(idProdutoSelecionado, nome, tipo, preco);

                if (alterado) {
                    Toast.makeText(MainActivity.this, "Produto alterado com sucesso!", Toast.LENGTH_SHORT).show();
                    listarProdutos();
                } else {
                    Toast.makeText(MainActivity.this, "Erro ao alterar produto.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Ação para excluir produto
        btnExcluir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (idProdutoSelecionado == -1) {
                    Toast.makeText(MainActivity.this, "Nenhum produto selecionado para exclusão.", Toast.LENGTH_SHORT).show();
                    return;
                }

                boolean excluido = dbHelper.excluirProduto(idProdutoSelecionado);

                if (excluido) {
                    Toast.makeText(MainActivity.this, "Produto excluído com sucesso!", Toast.LENGTH_SHORT).show();
                    listarProdutos();
                } else {
                    Toast.makeText(MainActivity.this, "Erro ao excluir produto.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Ação para encerrar a sessão
        btnEncerrarSessao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navegar para a LogoutActivity
                Intent intent = new Intent(MainActivity.this, LogoutActivity.class);
                startActivity(intent);
                finish();  // Finaliza a MainActivity para que não seja possível voltar
            }
        });

        listarProdutos();
    }

    private void listarProdutos() {
        Cursor cursor = dbHelper.exibirProdutos();
        listaProdutos.clear();
        listaIds.clear();

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndex(DBHelper.COLUNA_ID));
                String nome = cursor.getString(cursor.getColumnIndex(DBHelper.COLUNA_NOME));
                String tipo = cursor.getString(cursor.getColumnIndex(DBHelper.COLUNA_TIPO));
                double preco = cursor.getDouble(cursor.getColumnIndex(DBHelper.COLUNA_PRECO));

                listaIds.add(id);
                listaProdutos.add("Nome: " + nome + "\nTipo: " + tipo + "\nPreço: " + preco);
            } while (cursor.moveToNext());
        }

        cursor.close();

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listaProdutos);
        listViewProdutos.setAdapter(adapter);
    }

    @Override
    protected void onDestroy() {
        dbHelper.close();
        super.onDestroy();
    }
}
